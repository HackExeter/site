var nodemailer = require("nodemailer");

var smtpTransport = nodemailer.createTransport("SMTP",{
   service: "Gmail",
   auth: {
       user: "ugurevin1@gmail.com",
       pass: "applepie"
   }
});

smtpTransport.sendMail({
   from: "My Name <ugurevin1@gmail.com.com>", // sender address
   to: "6038310555@vtext.com", // comma separated list of receivers
   subject: "", // Subject line
   text: "Hello world" // plaintext body
}, function(error, response){
   if(error){
       console.log(error);
   }else{
       console.log("Message sent: " + response.message);
   }
});

/*
var email = require('emailjs');



var mailserver  = email.server.connect({
   user:    "ugurevin1@gmail.com",
   password:"apple",
   host:    "smtp.gmail.com",
   ssl:     true
});

/*
var mailserver = email.server.connect({
  user: "hackexeterdemo@yahoo.com",
  password: "Hackexeterdemo2014"
});
*/
/*
var number = "6037212431@messaging.sprintpcs.com";
mailserver.send({
  text:    "i hope this works",
  from:    "HackExeterDemo <ugurevin1@gmail.com>",
  to:      number,
  //subject: "testing emailjs"
}, function(err, message) { console.log(err || message); });
*/
