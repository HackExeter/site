﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
namespace SMSLightningSharpLibrary
{
   public class SMSLightning
    {
        public enum CARRIERS
        {
            ATT, VIRGIN_MOBILE, VERIZON
        }
        private static string CARRIERToStr(CARRIERS c)
        {
            switch (c)
            {
                case SMSLightning.CARRIERS.ATT:
                    return "att";
                case SMSLightning.CARRIERS.VERIZON:
                    return "vzn";
                case SMSLightning.CARRIERS.VIRGIN_MOBILE:
                    return "vgn";
                default: return null;
            }
        }
        public const string SALTY_OASIS_LOCATION = "http://salty-oasis-3517.herokuapp.com/user";
        private RestClient client;
        public SMSLightning()
        {
            client = new RestClient(SALTY_OASIS_LOCATION);
        }
        public void Text(string number, CARRIERS carrier, string body)
        {
            const string sep = "|||";
            string format = number + sep;
            format += SMSLightning.CARRIERToStr(carrier) + sep;
            if (body.Length > 160)
            {
                Console.WriteLine("Warning: This text is over 160 characters, some cell phone providers might send it over multiple messages, or just not send it. It's best to keep your content under 160 characters...");
            }
            format += body;
            Console.WriteLine(format);

            RestRequest request = new RestRequest(Method.POST);
            request.AddParameter("name/", format);
            IRestResponse ir = client.Execute(request);
            //Console.WriteLine(ir.Content);
        }
    }
}
