﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMSLightningSharpLibrary;
namespace VeryBasicSMSLightningSharpTest
{
    class Program
    {
        static void Main(string[] args)
        {
            SMSLightning s = new SMSLightning();
            s.Text("6033205770", SMSLightning.CARRIERS.ATT, "this is from SMSLightning Sharp");
        }
    }
}
