require 'rest_client'
require 'redditkit'

# optional stuff we can do with an account - don't abuse these
throwawayaccount = "hackexthrowaway"
throwawaypassowrd = "hackexpassword"


puts "Please enter a subreddit, we'll text you the top link: "
sr = gets.chomp



links = RedditKit.front_page
links = RedditKit.links(sr)

title = nil

links.each do |link| #this is a hackathon
  title = link.title  #efficiency doesn't matter (neither does spelling)
  break #this works
end

puts title

puts "Please enter your number as 9 digits with no dashes: "
num = gets.chomp

puts """Please enter your carrier, vzn for Verizon, att for AT&T, vgn for Virgin Mobile..."""

carrier = gets.chomp
sep = '|||'
RestClient.post 'http://salty-oasis-3517.herokuapp.com/user',
#'http://smslightning-114218.use1-2.nitrousbox.com/user',#

 :name=>
    num + sep + carrier + sep + sr + ": " + title
