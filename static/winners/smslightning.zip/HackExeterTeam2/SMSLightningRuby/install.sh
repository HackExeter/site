
#sudo gem install twitter
sudo gem install rest-client
sudo gem install redditkit
