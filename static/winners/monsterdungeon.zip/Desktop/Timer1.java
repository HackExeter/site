import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Timer1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timer1 extends Actor
{
    int counter;
    World world;
    /**
     * Act - do whatever the Timer1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        // Add your action code here.
        counter++;
        if (counter == 500)
        {
            world = getWorld();
            world.addObject(new Monster(), rand(), 480);
        }
        else if (counter == 700)
        {
            world = getWorld();
            world.addObject(new Monster(), rand(), 480);
            world.addObject(new Monster(), rand(), 480);
        }
        else if (counter == 1500)
        {
            world = getWorld();
            world.addObject(new Monster(), rand(), 480);
            world.addObject(new Monster(), rand(), 480);
            world.addObject(new Monster(), rand(), 480);
            
        }
        else if (counter == 2250)
        {
            world = getWorld();
            world.addObject(new Monster(), rand(), 480);
            world.addObject(new Monster(), rand(), 480);
            world.addObject(new Monster(), rand(), 480);
        }
        else if (counter == 3000)
        {
            world.addObject(new Boss(), rand(), 300);
        }
           
    }    
    
    public Timer1()
    {
        counter = 0;
    }
    
    private int rand()
    {
        return Greenfoot.getRandomNumber(800);
    }
}
