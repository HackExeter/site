import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
   boolean isRight;
   World world;

    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (isRight)
           move(10);
        else
           move(-10);
           
       List<Actor> actors = getWorld().getObjects(Monster.class);
       for (int i = 0; i < actors.size(); i++)
       {
           Actor a = actors.get(i);
          if (Math.abs(a.getX() - this.getX()) <= 5 && Math.abs(a.getY() - this.getY()) <= 6) 
          {
              Monster m = (Monster) a;
              m.getHit();
              world = getWorld();
              world.removeObject(this);
              return;
          }
       }
       
       if (getX() <=1 || getX() >= 799)
       {
           world = getWorld();
           world.removeObject(this);
           return;
       }
       
       
    }    
    
    public Bullet(boolean right)
    {
        isRight = right;
    }
}
