import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Boss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss extends Actor
{
int timer = 0;
GreenfootImage img1 = new GreenfootImage("Boss.png");
GreenfootImage img2 = new GreenfootImage("Boss2.png");
    /**
     * Act - do whatever the Boss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        timer++;
        World world = getWorld();
        List<Actor> men = world.getObjects(Man.class);
        Man man = null;
        if (men.size() >= 1)
            man =  (Man) men.get(0);
        
        
        if (man != null && Math.abs(man.getX() - this.getX()) <= 40 && Math.abs(man.getY() - this.getY()) <= 20)
            man.takeDamage(50);
            
        if (man.getX() > getX())
        {
            move(1);
            setImage(img1);
        }
        else
        {
            move(-1);
            setImage(img2);
        }
        swingSword();
    }    
    
    public void swingSword()
    {
        if(getRotation() == 0 && timer == 5000)
        {
        setRotation(45);
        timer = 0;
    }
    if(getRotation() == 180 && timer == 5000)
    {
        setRotation(135);
        timer = 0;
    }
    if((getRotation() == 45 || getRotation() == 135) && timer == 250)
    {
        if(getRotation() == 45)
        {
            setRotation(0);
        }
        else
        {
            setRotation(180);
        }
    }
    }
}
