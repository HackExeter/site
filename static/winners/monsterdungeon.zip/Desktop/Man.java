import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Man here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Man extends Actor
{
    private int health;
    private int monstersKilled;
    private int v = 0;
    private boolean lastRight;
    private int count;
    private boolean shot;
    private GreenfootImage walkRight = new GreenfootImage("walking1.png");
    private GreenfootImage man = new GreenfootImage("man01.png");
    private GreenfootImage walkLeft = new GreenfootImage("walking2.png");
    
    public Man()
    {
        health = 100;
        monstersKilled = 0;
        lastRight = false;
        count = 0;
        shot = false;
    }
    
    /**
     * Act - do whatever the Man wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        Move();
    } 
    
    public void Move()
    {
        count++;
        if (count % 10 == 0)
            shot = false;
        
        
        String htext = "Health: " + health;
        World world = getWorld();
        World1 world1 = (World1) world;
        Message healthBox = world1.getHealthBox();
        healthBox.setText(htext);
        world.addObject(healthBox, 80, 20);
        
       if (Greenfoot.isKeyDown("right") )
       {
           setImage(walkRight);
           move(4);
           lastRight = true;
           if (Greenfoot.isKeyDown("shift"))
           {
               move(3);
           }
        }
        else if (Greenfoot.isKeyDown("left")) 
        {
            setImage(walkLeft);
           move(-4);
           lastRight = false;
           if (Greenfoot.isKeyDown("shift"))
           {
               move(-3);
           }
        }
        else
        {
            setImage(man);
        }
        
        if((Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("space")) && getY() == 480)
        {
            jump();
        }
        else if(getY() < 470)
        {
        gravity();
        }
        
        if (Greenfoot.isKeyDown("a"))
        {
            if (!shot)
            {
                world.addObject(new Bullet(lastRight), getX(), getY());
                shot = true;
            }
            
        }
    
        
        
        super.setLocation(super.getX( ) , super.getY() + v);    
        if(getY() > 480) 
        {
            super.setLocation(super.getX( ) , 480);
            v = 0;
        }
        
        
        
        if (health <= 0)
        {
            String text = "You Lose. Game over.";
            world = getWorld();
            world.removeObject(this);
            world1 = (World1) world;
            Message messagebox = world1.getMessage();
            messagebox.setText(text);
            world.addObject(messagebox, 700, 70);
            Greenfoot.stop();
        }
        else
        {
            String text = "score: " + monstersKilled;
            world = getWorld();
            world1 = (World1) world;
            Message messagebox = world1.getMessage();
            messagebox.setText(text);
            world.addObject(messagebox, 80, 70);
        }
        

        
    }
    
   
   public void jump()
   {
      v = -10;
    }
  
    public void gravity()
    {
        v = v+1;
    }
    
    public void takeDamage(int dmg)
    {
        health += -dmg;
    }
    
    public void killedMonster()
    {
        monstersKilled++;
        health += 5;
    }

}
