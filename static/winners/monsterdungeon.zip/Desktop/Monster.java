import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class Monster here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Monster extends Actor
{
    int difficulty;
    int numHits = 0;
    int health;
    private GreenfootImage left = new GreenfootImage("Monster1.png");
    private GreenfootImage right = new GreenfootImage("Monster2.png");
    
    /**
     * Act - do whatever the Monster wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        
        World world = getWorld();
        List<Actor> men = world.getObjects(Man.class);
        Man man = null;
        if (men.size() >= 1)
            man =  (Man) men.get(0);
        
        
        if (man != null && Math.abs(man.getX() - this.getX()) <= 15 && Math.abs(man.getY() - this.getY()) <= 15)
        {
            man.takeDamage(10);
        }
            
        if (man == null)
            return;
   
        
        if (man.getX() > getX())
        {
            move(1);
            setImage(right);
        }
        else
        {
            move(-1);
            setImage(left);
        }
            
        if (health <= 0)
        {
            world = getWorld();
            world.removeObject(this);
            man.killedMonster();
            return;
        }
    }    
    
    public void move()
    {
        
    }
    
    public Monster()
    {
        health = 100;
    }
    
    public void getHit()
    {
        health -= 5;
    }
    

    
}
